//
//  AppDelegate.h
//  DynamicAppIcon
//
//  Created by daiyi on 2017/5/1.
//  Copyright © 2017年 DY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

